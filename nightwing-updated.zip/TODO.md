# NightWing website — implementation outcomes

## [x] 1. Project story and three-pillar product narrative
- The website introduces NightWing as a privacy-first, crowdsourced dark-street and road-hazard mapping concept from Coding Divas for the Hack-A-Throne Sustainability & Smart Cities challenge.
- It explains the night-safety problem, the proposed solution, and the three pillars See, Avoid, Fix: See covers darkness detection, Danger Index, heatmap and dark-hours insight; Avoid covers safer routing, voice alerts, Safe Spots and women's-safety journeys; Fix covers outage diagnosis, repair prioritisation, evidence reporting and community verification.
- It introduces the citizen-facing and municipal-facing workflows and accurately describes NightWing as a concept/prototype, not a deployed or proven service.

## [x] 2. Illustrative safety and map experience
- The website illustrates the combined Danger Index for darkness and potholes, its red/orange/green road-segment states, and the published starting formula: 0.50 × darkness severity + 0.35 × pothole severity + 0.15 × traffic and vulnerable-location score.
- It demonstrates a fastest-versus-safer route comparison, with time and hazard trade-offs, and an example hands-free voice alert.
- It labels any map, route, metric and incident data as illustrative/simulated rather than live. The time controls change the displayed sample hotspot count and plotted markers; map-layer and route controls update their visual state.

## [x] 3. Personal safety and municipal repair workflows
- It explains Safe Spots and the women's Ride Watch and Smart Check-In journeys, including that alerts are intended to be triggered contextually by dark or risky conditions, and references existing emergency services rather than claiming to replace them.
- It explains smart outage diagnosis: an isolated dark segment suggests an individual bulb/fixture issue, while simultaneous nearby drops suggest an area-wide power cut routed to the electricity board.
- It shows transparent repair prioritisation, municipal progress visibility, and opt-in community verification after a repair is reported.

## [x] 4. Privacy, technology, MVP scope, and team
- It describes opt-in, anonymised/coarse light, motion and location observations; relative dark/dim/lit categories; aggregation across independent trips; and privacy-preserving heatmaps rather than publishing individual routes.
- It presents the proposed technology direction (React Native or Flutter and React web, phone light sensor/accelerometer/GPS, Python ML, PostgreSQL + PostGIS, OpenStreetMap and OSRM/GraphHopper routing) without claiming components are already integrated.
- It describes a focused campus/neighbourhood MVP and makes clear that prototype features or sample data may be simulated.
- It lists Prathika (Amrita School of Computing, Chennai), Githa Shri (SRM Easwari Engineering College), and Rashika Shri (Rajalakshmi Engineering College) as the Coding Divas team.

## [x] 5. Responsive, accessible light visual system
- The website uses a lighter, calm, accessible palette while retaining NightWing's night-safety identity, with responsive layouts and clear navigation across the product story. Interactive controls have visible keyboard focus, stronger contrast and accessible labels; the municipal queue uses semantic table markup.

## [x] 6. Working prototype at `/app` (Coding Divas additions)
- New route `/app` (`client/src/pages/Prototype.tsx`, engine in `client/src/prototype/engine.ts`, styles in `client/src/prototype/prototype.css`) using the site's existing palette and fonts.
- Sign-in gate: citizens use name, mobile number and a one-time code (shown on screen as a demo SMS); officials use officer ID and PIN (demo account GCC-W12 / 4821) with a 3-attempt lockout. Prototype checks run in the browser; production would verify both on the server.
- Citizen app: Danger map with a working Danger Index (0.50 darkness + 0.35 potholes + 0.15 vulnerable places), Dark Hours slider (8 PM to 2 AM), Safe Spots and per-road details; SafeRoute computes fastest vs. safer routes and plays voice alerts during a simulated ride.
- Women's Safety Mode appears only for women verified through a simulated DigiLocker step: trusted contacts, ride-app trip import, Ride Watch (route deviation into a dark zone) and Smart Check-In, with one-tap WhatsApp/SMS alert links and a police escalation card (112 / Kavalan SOS).
- City Authority console (officials only): repair dashboard with Smart Outage Diagnosis (bulb vs. area power cut), priority-ranked list, resident verification and ward report; Civic Bridge with partner sync and a Joint Safety Ledger.
- All data, partners and departments are simulated and labelled as such.

## [x] 7. Landing-page additions
- "Try the prototype" links in the navigation and hero; new "Two apps, one platform" and "Civic Bridge" sections (`client/src/landing-additions.css`). Existing sections, copy and colours are unchanged.

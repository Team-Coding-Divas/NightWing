import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  AlertTriangle, ArrowLeft, BadgeCheck, Building2, Car, Check, Clock3, Copy, Eye, FileText, Handshake, Landmark,
  Lightbulb, Lock, LogOut, MapPin, MessageCircle, Navigation, Phone, RefreshCw, ShieldCheck, Truck, UserRound, Volume2, Wrench, Zap,
} from "lucide-react";
import {
  LANDMARKS, M_PER_UNIT, NODES, SAFE_SPOTS, buildIndex, createSegments, danger, diagnose, dijkstra, hazardText, hourLabel,
  level, lightAt, lightCat, metres, nearestSafeSpot, parts, priority, priorityList, routeStats, zoneOf,
  type NodeId, type Route, type Segment,
} from "@/prototype/engine";
import "@/prototype/prototype.css";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */
type Gender = "" | "woman" | "man" | "other";
type Session =
  | { role: "citizen"; name: string; gender: Gender; womanVerified: boolean; consent: boolean }
  | { role: "authority"; officerId: string };
type CitizenTab = "map" | "route" | "women";
type AuthorityTab = "repairs" | "bridge";
type Tone = "" | "ok" | "warn" | "bad";
interface LogItem { id: number; time: string; text: string; tone: Tone }
interface Contact { name: string; phone: string }
interface Ride {
  path: NodeId[]; idx: number; t: number; speed: number; paused: boolean; done: boolean;
  warned: Set<number>; expectedIds?: Set<number>; divert?: boolean; offNoted?: boolean; armedNoted?: boolean; dest?: NodeId;
}

// Prototype-only officer account. The real app verifies officer accounts on the server.
const OFFICERS: Record<string, string> = { "GCC-W12": "4821" };

/* ------------------------------------------------------------------ */
/* Sign-in gate                                                        */
/* ------------------------------------------------------------------ */
function SignIn({ onEnter }: { onEnter: (s: Session) => void }) {
  const [who, setWho] = useState<"citizen" | "official">("citizen");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [gender, setGender] = useState<Gender>("");
  const [consent, setConsent] = useState(false);
  const [verified, setVerified] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [step, setStep] = useState<1 | 2>(1);
  const [otp, setOtp] = useState("");
  const [code, setCode] = useState("");
  const [err, setErr] = useState("");
  const [offId, setOffId] = useState("");
  const [pin, setPin] = useState("");
  const [offErr, setOffErr] = useState("");
  const fails = useRef(0);
  const lockUntil = useRef(0);

  const digits = phone.replace(/[^0-9]/g, "").replace(/^91(?=\d{10}$)/, "");

  function sendCode(ev: FormEvent) {
    ev.preventDefault();
    if (!name.trim()) return setErr("Enter your name.");
    if (digits.length !== 10) return setErr("Enter a 10-digit mobile number.");
    if (!gender) return setErr("Select your gender.");
    if (gender === "woman" && !verified) return setErr("Please verify through DigiLocker first. Women's accounts must be verified before signing in.");
    setErr("");
    setOtp(String(1000 + Math.floor(Math.random() * 9000)));
    setStep(2);
  }
  function verifyCode() {
    if (code.trim() !== otp) return setErr("That code doesn't match. Check the code and try again.");
    if (gender === "woman" && !verified) return setErr("Please verify through DigiLocker first.");
    onEnter({ role: "citizen", name: name.trim(), gender, womanVerified: gender === "woman" && verified, consent });
  }
  function startVerify() {
    setVerifying(true);
    window.setTimeout(() => { setVerifying(false); setVerified(true); }, 900);
  }
  function officialSignIn(ev: FormEvent) {
    ev.preventDefault();
    const now = Date.now();
    if (now < lockUntil.current) return setOffErr(`Too many attempts. Try again in ${Math.ceil((lockUntil.current - now) / 1000)} seconds.`);
    const id = offId.trim().toUpperCase();
    if (OFFICERS[id] && OFFICERS[id] === pin.trim()) { fails.current = 0; onEnter({ role: "authority", officerId: id }); return; }
    fails.current += 1; setPin("");
    if (fails.current >= 3) { lockUntil.current = now + 30000; fails.current = 0; setOffErr("Too many attempts. Sign-in is locked for 30 seconds."); }
    else setOffErr("Officer ID or PIN is not recognised. Citizens should use the Citizen tab.");
  }

  return (
    <div className="pt-gate">
      <div className="pt-gate-inner">
        <div className="pt-gate-hero">
          <a className="pt-back" href="/"><ArrowLeft size={15} /> Back to the NightWing story</a>
          <span className="eyebrow"><span className="eyebrow-dot" /> WORKING PROTOTYPE</span>
          <h1>Sign in to<br /><em>NightWing.</em></h1>
          <p>One platform, two apps. Each person sees only what they need.</p>
          <ul className="pt-gate-points">
            <li><span className="pt-dot pt-dot-green" /><div><strong>Citizens</strong><small>Danger map and safer routes. Women verify once through DigiLocker and also get Women's Safety Mode.</small></div></li>
            <li><span className="pt-dot pt-dot-peach" /><div><strong>City officials</strong><small>Repair dashboard, outage diagnosis and the Civic Bridge. Citizens cannot open it.</small></div></li>
          </ul>
          <p className="pt-fine">Simulated pilot data for one campus neighbourhood. Codes and verification are demonstrations only.</p>
        </div>
        <div className="pt-gate-card">
          <div className="pt-seg" role="tablist" aria-label="Sign in as">
            <button type="button" role="tab" aria-selected={who === "citizen"} onClick={() => setWho("citizen")}><UserRound size={15} /> Citizen</button>
            <button type="button" role="tab" aria-selected={who === "official"} onClick={() => setWho("official")}><Building2 size={15} /> City official</button>
          </div>

          {who === "citizen" ? (
            <form className="pt-form" onSubmit={sendCode} noValidate>
              <h2>Citizen app</h2>
              {step === 1 ? (
                <>
                  <label className="pt-field" htmlFor="pt-name">Your name<input id="pt-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Prathika" autoComplete="off" /></label>
                  <label className="pt-field" htmlFor="pt-phone">Mobile number<input id="pt-phone" type="tel" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="10-digit mobile number" autoComplete="off" /></label>
                  <label className="pt-field" htmlFor="pt-gender">Gender
                    <select id="pt-gender" value={gender} onChange={(e) => { const g = e.target.value as Gender; setGender(g); if (g !== "woman") setVerified(false); }}>
                      <option value="">Select</option><option value="woman">Woman</option><option value="man">Man</option><option value="other">Other / prefer not to say</option>
                    </select>
                  </label>
                  {gender === "woman" && (
                    <div className="pt-verify">
                      <p><strong>Women must verify before signing in.</strong> Verify once through DigiLocker to open NightWing and unlock Women's Safety Mode. NightWing keeps only a "verified" flag, never your documents.</p>
                      <div className="pt-row">
                        {!verified && <button type="button" className="pt-btn pt-btn-sm" onClick={startVerify} disabled={verifying}><BadgeCheck size={14} /> {verifying ? "Checking with DigiLocker…" : "Verify with DigiLocker (demo)"}</button>}
                        <span className={`pt-chip ${verified ? "pt-chip-green" : ""}`}>{verified ? "Verified (demo)" : "Not verified"}</span>
                      </div>
                    </div>
                  )}
                  <label className="pt-check" htmlFor="pt-consent"><input id="pt-consent" type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} /> Share anonymous light and pothole readings during night trips (optional, can be turned off any time)</label>
                  <p className="pt-err" role="alert">{err}</p>
                  <button className="pt-btn pt-btn-primary" type="submit">Send code</button>
                </>
              ) : (
                <>
                  <div className="pt-sms"><small>Demo SMS to +91 {digits.slice(0, 5)} {digits.slice(5)} (not actually sent)</small>Your NightWing code is <b>{otp}</b></div>
                  <label className="pt-field" htmlFor="pt-otp">Enter the 4-digit code<input id="pt-otp" inputMode="numeric" maxLength={4} value={code} onChange={(e) => setCode(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); verifyCode(); } }} autoComplete="one-time-code" autoFocus /></label>
                  <p className="pt-err" role="alert">{err}</p>
                  <div className="pt-row"><button type="button" className="pt-btn pt-btn-primary" onClick={verifyCode}>Verify and continue</button><button type="button" className="pt-btn" onClick={() => { setStep(1); setErr(""); setCode(""); }}>Change number</button></div>
                </>
              )}
            </form>
          ) : (
            <form className="pt-form" onSubmit={officialSignIn} noValidate>
              <h2>City Authority console</h2>
              <p className="pt-fine">For ward engineers, the electricity board and police. Citizens cannot open this console.</p>
              <label className="pt-field" htmlFor="pt-off">Officer ID<input id="pt-off" value={offId} onChange={(e) => setOffId(e.target.value)} placeholder="e.g. GCC-W12" autoComplete="off" /></label>
              <label className="pt-field" htmlFor="pt-pin">PIN<input id="pt-pin" type="password" inputMode="numeric" value={pin} onChange={(e) => setPin(e.target.value)} autoComplete="off" /></label>
              <p className="pt-err" role="alert">{offErr}</p>
              <button className="pt-btn pt-btn-primary" type="submit"><Lock size={14} /> Sign in</button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Small UI helpers                                                    */
/* ------------------------------------------------------------------ */
const zoneLabel = { red: "Red zone", orange: "Orange zone", green: "Green zone" } as const;
function Chip({ zone, children }: { zone?: "red" | "orange" | "green" | "ink"; children: ReactNode }) {
  return <span className={`pt-chip ${zone ? `pt-chip-${zone}` : ""}`}>{children}</span>;
}
function Log({ items, empty }: { items: LogItem[]; empty: string }) {
  if (!items.length) return <p className="pt-empty">{empty}</p>;
  return <ol className="pt-log">{items.map((l) => <li key={l.id} className={l.tone ? `pt-log-${l.tone}` : ""}><b>{l.time}</b>{l.text}</li>)}</ol>;
}
function copyText(text: string, btn: HTMLButtonElement) {
  const orig = btn.textContent;
  try {
    navigator.clipboard.writeText(text).then(() => { btn.textContent = "Copied"; }, () => { btn.textContent = "Select the text to copy"; });
  } catch { btn.textContent = "Select the text to copy"; }
  window.setTimeout(() => { btn.textContent = orig; }, 1800);
}
function phoneDigits(p: string) { let d = p.replace(/[^0-9]/g, ""); if (d.length === 10) d = "91" + d; return d; }

/* ------------------------------------------------------------------ */
/* Workspace                                                           */
/* ------------------------------------------------------------------ */
function Workspace({ session, onSignOut }: { session: Session; onSignOut: () => void }) {
  const citizen = session.role === "citizen";
  const womanVerified = session.role === "citizen" && session.womanVerified;

  const segsRef = useRef<Segment[]>(createSegments());
  const segs = segsRef.current;
  const idx = useMemo(() => buildIndex(segs), [segs]);
  const [version, setVersion] = useState(0);
  const bump = useCallback(() => setVersion((v) => v + 1), []);

  const [hour, setHour] = useState(22);
  const hourRef = useRef(hour); hourRef.current = hour;
  const [tab, setTab] = useState<CitizenTab | AuthorityTab>(citizen ? "map" : "repairs");
  const [sel, setSel] = useState(31);

  // logs
  const logId = useRef(0);
  const [rideLog, setRideLog] = useState<LogItem[]>([]);
  const [cabLog, setCabLog] = useState<LogItem[]>([]);
  const [bridgeLog, setBridgeLog] = useState<LogItem[]>([]);
  const mk = (text: string, tone: Tone): LogItem => ({ id: ++logId.current, time: hourLabel(hourRef.current), text, tone });
  const addRide = useCallback((t: string, tone: Tone = "") => setRideLog((l) => [mk(t, tone), ...l]), []); // eslint-disable-line react-hooks/exhaustive-deps
  const addCab = useCallback((t: string, tone: Tone = "") => setCabLog((l) => [mk(t, tone), ...l]), []); // eslint-disable-line react-hooks/exhaustive-deps
  const addBridge = useCallback((t: string, tone: Tone = "") => setBridgeLog((l) => [mk(t, tone), ...l]), []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (session.role === "citizen") {
      addRide(`Signed in as ${session.name}. ${session.consent ? "Sharing anonymous road readings during night trips." : "Not sharing road readings. Every feature still works."}`, "ok");
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  /* ---------- voice ---------- */
  const [voice, setVoice] = useState(true);
  const voiceRef = useRef(voice); voiceRef.current = voice;
  const say = useCallback((text: string) => {
    if (!voiceRef.current || !("speechSynthesis" in window)) return;
    try { window.speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text); u.lang = "en-IN"; window.speechSynthesis.speak(u); } catch { /* speech unavailable */ }
  }, []);

  /* ---------- SafeRoute ---------- */
  const [from, setFrom] = useState<NodeId>("R");
  const [to, setTo] = useState<NodeId>("F");
  const safeCost = useCallback((e: Segment) => e.len * (1 + 4 * danger(e, hourRef.current)), []);
  const routes = useMemo(() => {
    if (from === to) return null;
    const fast = dijkstra(idx, from, to, (e) => e.len);
    const safe = dijkstra(idx, from, to, (e) => e.len * (1 + 4 * danger(e, hour)));
    return fast && safe ? { fast, safe } : null;
  }, [from, to, hour, idx, version]); // eslint-disable-line react-hooks/exhaustive-deps

  /* ---------- Women's Safety ---------- */
  const [contacts, setContacts] = useState<Contact[]>(() => {
    try { const s = JSON.parse(localStorage.getItem("nw_contacts") || "null"); if (Array.isArray(s) && s.length === 3) return s as Contact[]; } catch { /* storage unavailable */ }
    return [{ name: "Amma", phone: "" }, { name: "Roommate", phone: "" }, { name: "", phone: "" }];
  });
  useEffect(() => { try { localStorage.setItem("nw_contacts", JSON.stringify(contacts)); } catch { /* storage unavailable */ } }, [contacts]);
  const contactsRef = useRef(contacts); contactsRef.current = contacts;
  const [veh, setVeh] = useState(""); const vehRef = useRef(veh); vehRef.current = veh;
  const [drv, setDrv] = useState(""); const drvRef = useRef(drv); drvRef.current = drv;
  const [pick, setPick] = useState<NodeId>("C");
  const [dest, setDest] = useState<NodeId>("F");
  const [checkinOn, setCheckinOn] = useState(true); const checkinRef = useRef(checkinOn); checkinRef.current = checkinOn;
  const [wsAlert, setWsAlert] = useState<null | { kind: "ride" | "checkin" | "off" | "same"; road: string }>(null);
  const alertedRef = useRef(false);
  const [cabState, setCabState] = useState<"idle" | "running" | "paused" | "done">("idle");
  const [wrongUsed, setWrongUsed] = useState(false);
  const [checkin, setCheckin] = useState<null | { road: string; count: number }>(null);
  const checkTimer = useRef<number | null>(null);

  const contactNames = () => {
    const n = contactsRef.current.filter((c) => c.name || c.phone).map((c) => c.name || c.phone);
    return n.length > 1 ? `${n.slice(0, -1).join(", ")} and ${n[n.length - 1]}` : n[0] || "your trusted contacts";
  };
  const tripText = () => (vehRef.current.trim() ? ` Vehicle: ${vehRef.current.trim()}${drvRef.current.trim() ? ` (driver ${drvRef.current.trim()})` : ""}.` : "");
  const alertMessage = (kind: "ride" | "checkin", road: string) => {
    const when = hourLabel(hourRef.current);
    return (kind === "ride"
      ? `NightWing ALERT: My auto/cab left the expected route and entered a dark road (${road}) at ${when}. Please call me now. If I don't answer, call 112.`
      : `NightWing ALERT: I didn't respond to a safety check-in after my ride stopped on a dark road (${road}) at ${when}. Please call me now. If I don't answer, call 112.`) + tripText();
  };

  /* ---------- Ride engine ---------- */
  const rideRef = useRef<Ride | null>(null);
  const cabRef = useRef<Ride | null>(null);
  const [movers, setMovers] = useState<{ rider: { x: number; y: number } | null; cab: { x: number; y: number } | null }>({ rider: null, cab: null });
  const raf = useRef<number | null>(null);
  const last = useRef(0);
  const [riding, setRiding] = useState(false);

  const cur = (r: Ride) => idx.between.get(r.path[r.idx] + r.path[r.idx + 1])!;
  const pos = (r: Ride) => {
    if (r.done) { const n = NODES[r.path[r.path.length - 1]]; return { x: n.x, y: n.y }; }
    const A = NODES[r.path[r.idx]], B = NODES[r.path[r.idx + 1]], f = Math.min(1, r.t / cur(r).len);
    return { x: A.x + (B.x - A.x) * f, y: A.y + (B.y - A.y) * f };
  };

  const watchCab = (r: Ride) => {
    const e = cur(r); if (!e) return;
    const h = hourRef.current, off = !r.expectedIds!.has(e.id), dark = lightAt(e, h) < 0.3;
    if (off && dark && !alertedRef.current) {
      alertedRef.current = true;
      setWsAlert({ kind: "ride", road: e.name });
      const msg = `Ride Watch alert. Your vehicle left the expected route and entered a dark zone on ${e.name}. Tap send to alert ${contactNames()}.`;
      addCab(msg, "bad"); say(msg);
      addBridge(`Police control room escalation prepared: ${e.name}${vehRef.current.trim() ? `, vehicle ${vehRef.current.trim()}` : ""}. Shared on the rider's confirmation.`, "bad");
    } else if (off && !r.offNoted) {
      r.offNoted = true; addCab(`Off the expected route on ${e.name}, which is lit. Monitoring.`, "warn");
      if (!alertedRef.current) setWsAlert({ kind: "off", road: e.name });
    }
    if (dark && checkinRef.current && !r.armedNoted) { r.armedNoted = true; addCab(`Entered a dark stretch (${e.name}). Smart Check-In is armed.`, "warn"); }
  };

  const onEnter = (r: Ride, kind: "ride" | "cab") => {
    if (kind === "cab") {
      if (r.divert) {
        const fromN = r.path[r.idx];
        const c = (e: Segment) => e.len * (0.2 + lightAt(e, hourRef.current) * 4);
        const dev = dijkstra(idx, fromN, r.dest!, c, new Set(r.expectedIds)) || dijkstra(idx, fromN, r.dest!, c);
        if (dev) r.path = r.path.slice(0, r.idx).concat(dev.nodes);
        r.divert = false;
        addCab(`Vehicle turned away from the expected route at ${NODES[fromN].name}.`, "warn");
      }
      watchCab(r);
    }
  };
  const onFrame = (r: Ride) => {
    const a = r.path[r.idx + 1], b = r.path[r.idx + 2]; if (!b) return;
    const n = idx.between.get(a + b)!; if (r.warned.has(n.id)) return;
    const remain = (cur(r).len - r.t) * M_PER_UNIT;
    if (remain <= 200) {
      r.warned.add(n.id);
      const t = hazardText(n, hourRef.current, remain);
      if (t) { addRide(`${t} (${n.name})`, lightAt(n, hourRef.current) < 0.3 && n.potholes ? "bad" : "warn"); say(t); }
    }
  };
  const step = (r: Ride, dt: number, kind: "ride" | "cab") => {
    r.t += r.speed * dt;
    while (!r.done && r.t >= cur(r).len) {
      r.t -= cur(r).len; r.idx++;
      if (r.idx >= r.path.length - 1) {
        r.done = true; r.t = 0;
        if (kind === "ride") { addRide(`Arrived at ${NODES[r.path[r.path.length - 1]].name}.`, "ok"); say("You have arrived."); setRiding(false); }
        else { setCabState("done"); addCab(`Arrived at ${NODES[r.path[r.path.length - 1]].name}. Ride Watch ended.`, "ok"); }
        break;
      }
      onEnter(r, kind);
    }
    if (!r.done && kind === "ride") onFrame(r);
  };
  const tick = (ts: number) => {
    const dt = last.current ? Math.min(0.05, (ts - last.current) / 1000) : 0; last.current = ts;
    const rr = rideRef.current, cr = cabRef.current;
    if (rr && !rr.paused && !rr.done) step(rr, dt, "ride");
    if (cr && !cr.paused && !cr.done) step(cr, dt, "cab");
    setMovers({ rider: rr ? pos(rr) : null, cab: cr ? pos(cr) : null });
    if ([rr, cr].some((r) => r && !r.done)) raf.current = requestAnimationFrame(tick);
    else { raf.current = null; last.current = 0; }
  };
  const loop = () => { if (raf.current == null) { last.current = 0; raf.current = requestAnimationFrame(tick); } };
  useEffect(() => () => { if (raf.current != null) cancelAnimationFrame(raf.current); if (checkTimer.current) window.clearInterval(checkTimer.current); try { window.speechSynthesis?.cancel(); } catch { /* ignore */ } }, []);

  function startRide(route: Route) {
    const r: Ride = { path: route.nodes.slice(), idx: 0, t: 0, speed: 70, paused: false, done: false, warned: new Set() };
    rideRef.current = r; setRiding(true);
    addRide(`Ride started: ${NODES[route.nodes[0]].name} to ${NODES[route.nodes[route.nodes.length - 1]].name}.`);
    const first = route.edges[0], t0 = hazardText(first, hour, null);
    if (t0) { r.warned.add(first.id); const m = `Caution. You are starting on a ${t0.charAt(0).toLowerCase()}${t0.slice(1)}`; addRide(`${m} (${first.name})`, "warn"); say(m); }
    else if (!route.edges.some((e) => hazardText(e, hour, null))) say("Safest route selected. This route is well lit with no potholes reported.");
    loop();
  }
  function stopRide() { rideRef.current = null; setRiding(false); setMovers((m) => ({ ...m, rider: null })); try { window.speechSynthesis?.cancel(); } catch { /* ignore */ } }

  function clearCheckin() { if (checkTimer.current) { window.clearInterval(checkTimer.current); checkTimer.current = null; } setCheckin(null); }
  function startCab() {
    if (pick === dest) { setWsAlert({ kind: "same", road: "" }); return; }
    clearCheckin();
    const expected = dijkstra(idx, pick, dest, safeCost)!;
    alertedRef.current = false; setWsAlert(null); setWrongUsed(false);
    const r: Ride = { path: expected.nodes.slice(), idx: 0, t: 0, speed: 60, paused: false, done: false, warned: new Set(), expectedIds: new Set(expected.edges.map((e) => e.id)), dest };
    cabRef.current = r; setCabState("running"); setExpected(expected);
    addCab(`Ride Watch on: ${NODES[pick].name} to ${NODES[dest].name}. Trusted contacts: ${contactNames()}.`);
    watchCab(r); loop();
  }
  const [expected, setExpected] = useState<Route | null>(null);
  function wrongTurn() { const r = cabRef.current; if (r && !r.done) { r.divert = true; setWrongUsed(true); addCab("Simulating: the driver will take a wrong turn at the next junction."); } }
  function stopCab() {
    const r = cabRef.current; if (!r || r.done) return;
    r.paused = true; setCabState("paused");
    const e = cur(r);
    if (lightAt(e, hour) < 0.3 && checkinOn) {
      addCab(`Unexpected stop on a dark stretch (${e.name}). Asking "Are you okay?"`, "warn");
      say("Are you okay? Tap I'm safe to confirm.");
      setCheckin({ road: e.name, count: 10 });
      checkTimer.current = window.setInterval(() => {
        setCheckin((c) => {
          if (!c) return c;
          if (c.count <= 1) {
            if (checkTimer.current) { window.clearInterval(checkTimer.current); checkTimer.current = null; }
            setWsAlert({ kind: "checkin", road: c.road });
            const m = `No reply to Smart Check-In. Tap send to alert ${contactNames()}.`;
            addCab(m, "bad"); say(m);
            addBridge(`Smart Check-In missed on ${c.road}. Police control room escalation prepared.`, "bad");
            return null;
          }
          return { ...c, count: c.count - 1 };
        });
      }, 1000);
    } else addCab(`Stopped on ${e.name}, which is ${lightCat(lightAt(e, hour))}. Smart Check-In stays quiet on lit roads.`);
  }
  function resumeCab() { const r = cabRef.current; if (r) { r.paused = false; setCabState("running"); addCab("Ride resumed."); loop(); } }
  function importTrip() {
    setVeh("TN 09 BX 4821"); setDrv("R. Kumar");
    addCab("Trip details imported from partner ride app (demo): TN 09 BX 4821, driver R. Kumar.");
    addBridge("Ride-hailing partner shared trip details for Ride Watch: TN 09 BX 4821.");
  }

  /* ---------- Repairs & Civic Bridge ---------- */
  const [diag, setDiag] = useState<null | { type: "bulb" | "power"; area: string; count: number; road?: string }>(null);
  const [report, setReport] = useState("");
  const ticketFor = (e: Segment) => { if (!e.ticket) e.ticket = `NW-${1040 + e.id}`; return e.ticket; };

  function simBulb() {
    const c = segs.filter((e) => !e.fault && e.status === "open" && lightAt(e, hour) >= 0.6);
    if (!c.length) return;
    const pool = c.filter((e) => e.vuln === 1).length ? c.filter((e) => e.vuln === 1) : c;
    const e = pool[Math.floor(Math.random() * pool.length)];
    e.fault = "bulb"; e.persist = 0; e.reports = 1;
    setDiag({ ...diagnose([e]), road: e.name }); setSel(e.id);
    addBridge(`Bulb failure detected on ${e.name}. Ticket ${ticketFor(e)} sent to City Corporation.`, "warn"); bump();
  }
  function simPower() {
    const area = "South East"; const dropped: Segment[] = [];
    segs.forEach((e) => { if (e.area === area) { if (lightAt(e, hour) >= 0.3) dropped.push(e); e.fault = "power"; } });
    setDiag(diagnose(dropped.length >= 4 ? dropped : segs.filter((e) => e.area === area)));
    addBridge(`Area power cut in ${area}: report sent to Electricity Board, not to streetlight teams.`, "warn"); bump();
  }
  function restore() { segs.forEach((e) => { e.fault = null; }); setDiag(null); bump(); }
  function act(e: Segment, a: "repair" | "lit" | "dark") {
    if (a === "repair") { e.status = "pending"; addBridge(`City Corporation marked ticket ${ticketFor(e)} (${e.name}) as repaired. Nearby residents asked to confirm.`); }
    else if (a === "lit") { e.status = "verified"; e.fault = null; addBridge(`Ticket ${ticketFor(e)} closed: residents confirmed ${e.name} is now lit. Navigation partner updated.`, "ok"); }
    else { e.status = "reopened"; e.reports++; e.persist++; addBridge(`Ticket ${ticketFor(e)} reopened: residents report ${e.name} is still dark.`, "bad"); }
    bump();
  }
  function makeReport() {
    const list = priorityList(segs, hour);
    let t = `NIGHTWING WARD REPAIR REPORT\nPilot area: campus neighbourhood (prototype data)\nSnapshot: ${hourLabel(hour)}\n\nPRIORITY REPAIRS (City Corporation)\n`;
    list.filter((e) => e.status !== "verified").forEach((e, i) => {
      t += `${i + 1}. ${e.name} (${e.area}) - ${lightCat(lightAt(e, hour))}, ${e.potholes} pothole(s), ${e.fault === "bulb" ? "new bulb failure" : `dark for ${e.persist} days`}, ${e.reports} report(s), priority ${priority(e, hour)}/100, status: ${e.status}${e.ticket ? `, ticket ${e.ticket}` : ""}\n`;
    });
    const ver = segs.filter((e) => e.status === "verified");
    t += `\nVERIFIED REPAIRS\n${ver.length ? ver.map((e) => `- ${e.name}`).join("\n") : "- None yet"}\n`;
    const pw = segs.filter((e) => e.fault === "power");
    t += `\nPOWER OUTAGES (sent to Electricity Board, excluded above)\n${pw.length ? `- ${pw[0].area}: ${pw.length} segments` : "- None"}\n`;
    setReport(t);
  }
  function partnerSync() {
    const dark = segs.filter((e) => e.fault !== "power" && lightAt(e, hour) < 0.6 && e.status !== "verified");
    dark.slice().sort(() => Math.random() - 0.5).slice(0, 3).forEach((e) => {
      const n = 2 + Math.floor(Math.random() * 4); e.reports += n; e.foundBy = "Delivery fleet";
      addBridge(`Delivery partner fleet: ${n} riders confirmed ${e.name} is ${lightCat(lightAt(e, hour))}${e.potholes ? " with potholes" : ""} (+${n} readings).`, "warn");
    });
    priorityList(segs, hour).filter((e) => e.status !== "verified").forEach((e) => {
      if (!e.ticket) { ticketFor(e); addBridge(`Ticket ${e.ticket} raised with City Corporation for ${e.name} (priority ${priority(e, hour)}).`); }
    });
    if (segs.some((e) => e.fault === "power")) addBridge("Electricity Board notified: area outage in South East. Streetlight tickets held back.", "warn");
    addBridge(`Navigation partner received the Danger Index for ${segs.length} segments; ${segs.filter((e) => zoneOf(e, hour) === "red").length} red segments will be avoided at night.`, "ok");
    bump();
  }

  /* ---------- tabs ---------- */
  const citizenTabs: { id: CitizenTab; label: string; icon: ReactNode }[] = [
    { id: "map", label: "Danger map", icon: <Eye size={15} /> },
    { id: "route", label: "SafeRoute", icon: <Navigation size={15} /> },
    ...(womanVerified ? [{ id: "women" as CitizenTab, label: "Women's Safety", icon: <ShieldCheck size={15} /> }] : []),
  ];
  const authorityTabs: { id: AuthorityTab; label: string; icon: ReactNode }[] = [
    { id: "repairs", label: "Repair dashboard", icon: <Wrench size={15} /> },
    { id: "bridge", label: "Civic Bridge", icon: <Handshake size={15} /> },
  ];
  const tabs = citizen ? citizenTabs : authorityTabs;
  const seg = segs[sel];

  /* ---------- map ---------- */
  const showRoutes = tab === "route" && routes;
  const showExpected = tab === "women" && expected && cabState !== "idle";
  const poly = (nodes: NodeId[]) => nodes.map((k) => `${NODES[k].x},${NODES[k].y}`).join(" ");
  const counts = { red: 0, orange: 0, green: 0 };
  segs.forEach((e) => { counts[zoneOf(e, hour)]++; });

  const map = (
    <svg className="pt-map" viewBox="0 0 1000 660" role="img" aria-label="Simulated pilot neighbourhood with roads coloured by Danger Index">
      <defs><pattern id="ptDots" width="21" height="21" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r=".8" fill="#bac9c1" opacity=".56" /></pattern></defs>
      <rect width="1000" height="660" fill="#eff3ec" /><rect width="1000" height="660" fill="url(#ptDots)" />
      {[80, 300, 520, 760].map((x, i, xs) => [80, 250, 420].map((y, j) => {
        const nx = [300, 520, 760, 920][i], ny = [250, 420, 580][j];
        return <rect key={`${x}-${y}`} x={x + 22} y={y + 22} width={nx - x - 44} height={ny - y - 44} rx="12" fill="#e2ede5" />;
      }))}
      {segs.map((e) => lightAt(e, hour) >= 0.6 && <line key={`g${e.id}`} className="pt-glow" x1={NODES[e.a].x} y1={NODES[e.a].y} x2={NODES[e.b].x} y2={NODES[e.b].y} />)}
      {segs.map((e) => <line key={`c${e.id}`} className="pt-casing" x1={NODES[e.a].x} y1={NODES[e.a].y} x2={NODES[e.b].x} y2={NODES[e.b].y} />)}
      {seg && <line className="pt-sel" x1={NODES[seg.a].x} y1={NODES[seg.a].y} x2={NODES[seg.b].x} y2={NODES[seg.b].y} />}
      {segs.map((e) => <line key={`r${e.id}`} className={`pt-road pt-road-${zoneOf(e, hour)} ${e.fault === "power" ? "pt-road-power" : ""} ${showRoutes || showExpected ? "pt-road-dim" : ""}`} x1={NODES[e.a].x} y1={NODES[e.a].y} x2={NODES[e.b].x} y2={NODES[e.b].y} />)}
      {segs.map((e) => Array.from({ length: e.potholes }, (_, k) => {
        const f = (k + 1) / (e.potholes + 1), A = NODES[e.a], B = NODES[e.b];
        return <circle key={`p${e.id}-${k}`} className="pt-pot" r="6" cx={A.x + (B.x - A.x) * f} cy={A.y + (B.y - A.y) * f} />;
      }))}
      {showRoutes && <><polyline className="pt-rt-case" points={poly(routes!.safe.nodes)} /><polyline className="pt-rt-safe" points={poly(routes!.safe.nodes)} /><polyline className="pt-rt-fast" points={poly(routes!.fast.nodes)} /></>}
      {showExpected && <><polyline className="pt-rt-case" points={poly(expected!.nodes)} /><polyline className="pt-rt-exp" points={poly(expected!.nodes)} /></>}
      {segs.map((e) => <line key={`h${e.id}`} className="pt-hit" onClick={() => { setSel(e.id); if (citizen) setTab("map"); }} x1={NODES[e.a].x} y1={NODES[e.a].y} x2={NODES[e.b].x} y2={NODES[e.b].y}><title>{e.name}</title></line>)}
      {SAFE_SPOTS.map((p, i) => <g key={`s${i}`} className="pt-spot"><rect x={p.x - 11} y={p.y - 11} width="22" height="22" rx="6" /><text x={p.x} y={p.y + 4}>{p.k}</text><title>{p.name}</title></g>)}
      {(Object.keys(NODES) as NodeId[]).map((k) => <circle key={`n${k}`} className={NODES[k].type ? "pt-node pt-node-lm" : "pt-node"} r={NODES[k].type ? 9 : 6} cx={NODES[k].x} cy={NODES[k].y} />)}
      {LANDMARKS.map((k) => <text key={`l${k}`} className="pt-lbl" x={NODES[k].x} y={NODES[k].y <= 80 ? NODES[k].y - 18 : NODES[k].y + 30}>{NODES[k].name}</text>)}
      {movers.rider && <circle className="pt-rider" r="10" cx={movers.rider.x} cy={movers.rider.y} />}
      {movers.cab && <circle className="pt-cab" r="10" cx={movers.cab.x} cy={movers.cab.y} />}
    </svg>
  );

  /* ---------- panels ---------- */
  function seePanel() {
    if (!seg) return null;
    const p = parts(seg, hour), d = p.dark + p.pot + p.vuln, lv = level(d), z = zoneOf(seg, hour), near = nearestSafeSpot(seg);
    const bar = (lab: string, v: number, cls: string) => <div className="pt-dbar"><span>{lab}</span><div className="pt-track"><i className={cls} style={{ width: `${Math.round(v * 100)}%` }} /></div><em>{Math.round(v * 100)}</em></div>;
    return (
      <>
        <p className="pt-kicker">CITIZEN APP · SEE</p>
        <h2>Where the danger is tonight</h2>
        <p className="pt-hint">Drag the time slider past midnight to see lights that fail late at night. Tap a road on the map to see its Danger Index.</p>
        <div className="pt-counts"><div className="pt-count pt-count-red"><b>{counts.red}</b><span>Dark + potholes</span></div><div className="pt-count pt-count-orange"><b>{counts.orange}</b><span>Dark or risky</span></div><div className="pt-count pt-count-green"><b>{counts.green}</b><span>Lower risk</span></div></div>
        <label className="pt-field" htmlFor="pt-seg">Road segment
          <select id="pt-seg" value={sel} onChange={(e) => setSel(Number(e.target.value))}>{segs.slice().sort((a, b) => a.name.localeCompare(b.name)).map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}</select>
        </label>
        <div className="pt-segcard">
          <h3>{seg.name}</h3>
          <p className="pt-sub">{NODES[seg.a].name} to {NODES[seg.b].name} · {seg.area} · {metres(seg.len)} m</p>
          <div className="pt-row"><Chip zone={z}>{zoneLabel[z]}</Chip><Chip>{lightCat(lightAt(seg, hour))} at {hourLabel(hour)}</Chip><Chip>{seg.potholes} pothole{seg.potholes === 1 ? "" : "s"}</Chip>{seg.fault === "power" && <Chip zone="orange">Power outage</Chip>}{seg.fault === "bulb" && <Chip zone="red">Bulb failure</Chip>}{seg.status === "verified" && <Chip zone="green">Repair verified</Chip>}</div>
          <div className="pt-score"><b>{Math.round(d * 100)}</b><Chip zone={lv.zone}>{lv.label} danger</Chip></div>
          <div className="pt-bars">{bar("Darkness × 0.50", p.dark, "pt-fill-dark")}{bar("Potholes × 0.35", p.pot, "pt-fill-road")}{bar("Vulnerable × 0.15", p.vuln, "pt-fill-context")}</div>
          <p className="pt-mini-title"><Clock3 size={13} /> Dark Hours timeline</p>
          <div className="pt-hours">{[20, 21, 22, 23, 24, 25, 26].map((h) => <div key={h}><i className={`pt-hz-${zoneOf(seg, h)}`} />{h % 24 % 12 || 12}{h % 24 < 12 ? "a" : "p"}</div>)}</div>
          <div className="pt-kv"><span>Nearest Safe Spot</span><span>{near.spot.name}, {near.metres} m</span></div>
          <div className="pt-kv"><span>Independent trips reporting</span><span>{seg.reports || "None"}</span></div>
          <div className="pt-kv"><span>Dark for</span><span>{seg.persist ? `${seg.persist} days` : "Not dark"}</span></div>
        </div>
      </>
    );
  }

  function routePanel() {
    const card = (kind: "fast" | "safe", r: Route) => {
      const st = routeStats(r, hour), lv = level(st.danger), same = routes!.fast.nodes.join() === routes!.safe.nodes.join();
      return (
        <div className={`pt-route ${kind === "safe" ? "pt-route-safe" : ""}`}>
          <span className="pt-route-t"><i className={kind === "safe" ? "pt-sw-safe" : "pt-sw-fast"} />{kind === "fast" ? "Fastest route" : "Safer route"}</span>
          <div className="pt-route-min">{st.min}<small>min · {st.km} km</small></div>
          <ul><li>{st.dark} dark stretch{st.dark === 1 ? "" : "es"}</li><li>{st.pot} pothole{st.pot === 1 ? "" : "s"}</li></ul>
          <Chip zone={lv.zone}>{lv.label} danger</Chip>
          <button type="button" className={`pt-btn pt-btn-sm ${kind === "safe" ? "pt-btn-primary" : ""}`} disabled={same && kind === "fast"} onClick={() => startRide(r)}>{same && kind === "fast" ? "Same as safer" : "Ride this route"}</button>
        </div>
      );
    };
    return (
      <>
        <p className="pt-kicker">CITIZEN APP · AVOID</p>
        <h2>SafeRoute: fastest or safer?</h2>
        <p className="pt-hint">NightWing penalises roads with a high Danger Index. Ride the fastest route to hear the voice alerts a rider would get.</p>
        <div className="pt-grid2">
          <label className="pt-field" htmlFor="pt-from">From<select id="pt-from" value={from} onChange={(e) => { stopRide(); setFrom(e.target.value as NodeId); }}>{LANDMARKS.map((k) => <option key={k} value={k}>{NODES[k].name}</option>)}</select></label>
          <label className="pt-field" htmlFor="pt-to">To<select id="pt-to" value={to} onChange={(e) => { stopRide(); setTo(e.target.value as NodeId); }}>{LANDMARKS.map((k) => <option key={k} value={k}>{NODES[k].name}</option>)}</select></label>
        </div>
        {routes ? <div className="pt-routes">{card("fast", routes.fast)}{card("safe", routes.safe)}</div> : <p className="pt-hint">Choose two different places.</p>}
        <div className="pt-row" style={{ marginTop: 12 }}>
          <label className="pt-check" htmlFor="pt-voice"><input id="pt-voice" type="checkbox" checked={voice} onChange={(e) => setVoice(e.target.checked)} /> <Volume2 size={14} /> Voice alerts</label>
          <button type="button" className="pt-btn pt-btn-sm" disabled={!riding} onClick={() => { stopRide(); addRide("Ride stopped."); }}>Stop ride</button>
        </div>
        <p className="pt-mini-title">Ride alerts</p>
        <Log items={rideLog} empty="Alerts appear here during a ride." />
      </>
    );
  }

  function sendPanel(kind: "ride" | "checkin", road: string) {
    const message = alertMessage(kind, road);
    const list = contacts.filter((c) => c.name || c.phone);
    return (
      <div className="pt-send">
        {list.length === 0 && <p className="pt-fine">Add trusted contacts above to send this alert.</p>}
        {list.map((c, i) => {
          const d = c.phone ? phoneDigits(c.phone) : "";
          if (d.length < 11) return <div className="pt-who" key={i}><b>{c.name || c.phone}</b><span className="pt-fine">Add a number above to message {c.name || "this contact"}.</span></div>;
          return (
            <div className="pt-who" key={i}><b>{c.name || c.phone}</b>
              <a className="pt-btn pt-btn-sm pt-btn-wa" href={`https://wa.me/${d}?text=${encodeURIComponent(message)}`} target="_blank" rel="noopener noreferrer"><MessageCircle size={14} /> Send on WhatsApp</a>
              <a className="pt-btn pt-btn-sm" href={`sms:+${d}?&body=${encodeURIComponent(message)}`}><Phone size={14} /> SMS</a>
            </div>
          );
        })}
        <label className="pt-field" htmlFor="pt-msg">Alert message<textarea id="pt-msg" readOnly value={message} /></label>
        <div className="pt-row"><button type="button" className="pt-btn pt-btn-sm" onClick={(e) => copyText(message, e.currentTarget)}><Copy size={14} /> Copy message</button><span className="pt-fine">WhatsApp opens with the message ready; tap send there.</span></div>
        <div className="pt-escalate"><Landmark size={16} /><span><b>Civic Bridge: police escalation.</b> Ready to share with the police control room: dark-zone location ({road}){veh.trim() ? `, vehicle ${veh.trim()}` : ""} and the expected route. Call <b>112</b> or use the Kavalan SOS app.</span></div>
      </div>
    );
  }

  function womenPanel() {
    return (
      <>
        <p className="pt-kicker">CITIZEN APP · WOMEN'S SAFETY MODE · VERIFIED</p>
        <h2>Ride Watch and Smart Check-In</h2>
        <p className="pt-hint">Share your destination before an auto or cab ride. If the vehicle leaves the expected route and enters a dark zone, your trusted contacts are alerted.</p>
        <p className="pt-mini-title">Trusted contacts</p>
        <div className="pt-contacts">
          {contacts.map((c, i) => (
            <div className="pt-grid2" key={i}>
              <label className="pt-field" htmlFor={`pt-cn${i}`}>Name<input id={`pt-cn${i}`} value={c.name} placeholder={i === 2 ? "Optional" : ""} onChange={(e) => setContacts((cs) => cs.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} autoComplete="off" /></label>
              <label className="pt-field" htmlFor={`pt-cp${i}`}>WhatsApp / mobile<input id={`pt-cp${i}`} type="tel" inputMode="tel" value={c.phone} placeholder={i === 2 ? "Optional" : "+91 98765 43210"} onChange={(e) => setContacts((cs) => cs.map((x, j) => (j === i ? { ...x, phone: e.target.value } : x)))} autoComplete="off" /></label>
            </div>
          ))}
        </div>
        <p className="pt-fine">Numbers stay in this browser only.</p>
        <p className="pt-mini-title">Trip details</p>
        <div className="pt-grid2">
          <label className="pt-field" htmlFor="pt-veh">Vehicle number<input id="pt-veh" value={veh} onChange={(e) => setVeh(e.target.value)} placeholder="e.g. TN 09 AB 1234" autoComplete="off" /></label>
          <label className="pt-field" htmlFor="pt-drv">Driver name<input id="pt-drv" value={drv} onChange={(e) => setDrv(e.target.value)} placeholder="Optional" autoComplete="off" /></label>
        </div>
        <div className="pt-row" style={{ marginTop: 8 }}><button type="button" className="pt-btn pt-btn-sm" onClick={importTrip}><Car size={14} /> Import trip from ride app (demo)</button></div>
        <div className="pt-grid2" style={{ marginTop: 12 }}>
          <label className="pt-field" htmlFor="pt-pick">Pickup<select id="pt-pick" value={pick} onChange={(e) => setPick(e.target.value as NodeId)}>{LANDMARKS.map((k) => <option key={k} value={k}>{NODES[k].name}</option>)}</select></label>
          <label className="pt-field" htmlFor="pt-dest">Destination<select id="pt-dest" value={dest} onChange={(e) => setDest(e.target.value as NodeId)}>{LANDMARKS.map((k) => <option key={k} value={k}>{NODES[k].name}</option>)}</select></label>
        </div>
        <label className="pt-check" htmlFor="pt-ci" style={{ marginTop: 10 }}><input id="pt-ci" type="checkbox" checked={checkinOn} onChange={(e) => setCheckinOn(e.target.checked)} /> Smart Check-In in dark zones</label>
        <div className="pt-row" style={{ marginTop: 10 }}>
          <button type="button" className="pt-btn pt-btn-primary" onClick={startCab}>Start auto ride</button>
          <button type="button" className="pt-btn" disabled={cabState !== "running" || wrongUsed} onClick={wrongTurn}>Simulate wrong turn</button>
          {cabState === "paused" ? <button type="button" className="pt-btn" onClick={resumeCab}>Resume ride</button> : <button type="button" className="pt-btn" disabled={cabState !== "running"} onClick={stopCab}>Simulate unexpected stop</button>}
        </div>
        {wsAlert && wsAlert.kind === "same" && <div className="pt-alert pt-alert-amber"><strong>Pick a different destination</strong><p>Pickup and destination are the same place.</p></div>}
        {wsAlert && wsAlert.kind === "off" && <div className="pt-alert pt-alert-amber"><strong>Off the expected route</strong><p>The road is lit, so no alert yet. NightWing keeps watching.</p></div>}
        {wsAlert && wsAlert.kind === "ride" && <div className="pt-alert"><strong><AlertTriangle size={15} /> Ride Watch alert: vehicle off route in a dark zone</strong><p>The vehicle entered <b>{wsAlert.road}</b>. Alert <b>{contactNames()}</b> now. Call 112 if you are in danger.</p>{sendPanel("ride", wsAlert.road)}</div>}
        {wsAlert && wsAlert.kind === "checkin" && <div className="pt-alert"><strong><AlertTriangle size={15} /> Smart Check-In: no reply</strong><p>No reply within the time limit on <b>{wsAlert.road}</b>. Alert <b>{contactNames()}</b> now.</p>{sendPanel("checkin", wsAlert.road)}</div>}
        <div className="pt-sos"><div><b>112</b><small>Emergency number. NightWing also links to Tamil Nadu Police's Kavalan SOS app.</small></div><button type="button" className="pt-btn pt-btn-sm" onClick={(e) => copyText("112", e.currentTarget)}>Copy number</button></div>
        <p className="pt-mini-title">Ride Watch log</p>
        <Log items={cabLog} empty="Start an auto ride to begin monitoring." />
      </>
    );
  }

  function repairsPanel() {
    const list = priorityList(segs, hour);
    const dark = segs.filter((e) => lightAt(e, hour) < 0.3).length, pots = segs.reduce((s, e) => s + e.potholes, 0);
    const outage = segs.some((e) => e.fault === "power"), ver = segs.filter((e) => e.status === "verified").length;
    return (
      <>
        <p className="pt-kicker">CITY AUTHORITY · FIX</p>
        <h2>Repair dashboard</h2>
        <p className="pt-hint">Smart Outage Diagnosis, a ranked repair list and resident verification for ward teams.</p>
        <div className="pt-tiles"><div><b>{segs.length}</b><span>Road segments mapped</span></div><div><b className="pt-red">{dark}</b><span>Dark at {hourLabel(hour)}</span></div><div><b>{pots}</b><span>Potholes confirmed</span></div><div><b>{outage ? 1 : ver}</b><span>{outage ? "Active power outage" : "Repairs verified"}</span></div></div>
        <p className="pt-mini-title"><Zap size={13} /> Smart Outage Diagnosis</p>
        <div className="pt-row"><button type="button" className="pt-btn pt-btn-sm" onClick={simBulb}><Lightbulb size={14} /> Simulate bulb failure</button><button type="button" className="pt-btn pt-btn-sm" onClick={simPower}><Zap size={14} /> Simulate area power cut</button><button type="button" className="pt-btn pt-btn-sm" onClick={restore}><RefreshCw size={14} /> Restore all</button></div>
        <div className="pt-diag">
          {!diag && <p>Simulate a fault. NightWing compares neighbouring roads at the same moment to decide who should get the report.</p>}
          {diag?.type === "bulb" && <><Chip zone="orange">1 segment dark, neighbours lit</Chip><strong>Probable bulb failure</strong><p><b>{diag.road}</b> went dark while nearby roads stayed lit. Report sent to the <b>City Corporation</b> streetlight team.</p></>}
          {diag?.type === "power" && <><Chip zone="ink">{diag.count} segments dark at once</Chip><strong>Probable power outage</strong><p>The whole <b>{diag.area}</b> area went dark at the same moment. Report sent to the <b>Electricity Board</b>; these roads stay off the streetlight repair list.</p></>}
        </div>
        <p className="pt-mini-title">Top dark spots by priority</p>
        <ol className="pt-prio">
          {list.map((e, i) => {
            const verified = e.status === "verified";
            return (
              <li key={e.id}>
                <span className="pt-rk">{verified ? <Check size={16} /> : i + 1}</span>
                <div><div className="pt-nm">{e.name}</div><div className="pt-row pt-meta"><Chip zone={verified ? "green" : zoneOf(e, hour)}>{lightCat(lightAt(e, hour))}</Chip><Chip>{e.potholes} pothole{e.potholes === 1 ? "" : "s"}</Chip><Chip>{e.fault === "bulb" ? "new fault" : `${e.persist} days`}</Chip><Chip>{e.area}</Chip></div></div>
                <div className="pt-ps">{verified ? "–" : priority(e, hour)}<small>PRIORITY</small></div>
                <div className="pt-acts">
                  {verified && <Chip zone="green">Verified lit by residents</Chip>}
                  {e.status === "pending" && <><span>Residents nearby confirm:</span><button type="button" className="pt-btn pt-btn-sm" onClick={() => act(e, "lit")}>Now lit</button><button type="button" className="pt-btn pt-btn-sm" onClick={() => act(e, "dark")}>Still dark</button></>}
                  {(e.status === "open" || e.status === "reopened") && <>{e.status === "reopened" && <Chip zone="red">Reopened: still dark</Chip>}<button type="button" className="pt-btn pt-btn-sm" onClick={() => act(e, "repair")}>Mark repaired</button></>}
                </div>
              </li>
            );
          })}
        </ol>
        <div className="pt-row" style={{ marginTop: 12 }}><button type="button" className="pt-btn pt-btn-primary" onClick={makeReport}><FileText size={14} /> Generate ward report</button>{report && <button type="button" className="pt-btn pt-btn-sm" onClick={(e) => copyText(report, e.currentTarget)}><Copy size={14} /> Copy report</button>}</div>
        {report && <pre className="pt-report">{report}</pre>}
      </>
    );
  }

  function bridgePanel() {
    const list = priorityList(segs, hour);
    const status = (e: Segment) => {
      if (e.status === "verified") return <><b className="pt-green">Closed</b><br />Verified lit by residents</>;
      if (e.status === "pending") return <><b className="pt-orange">Repair reported</b><br />Awaiting resident check</>;
      if (e.status === "reopened") return <><b className="pt-red">Reopened</b><br />Residents say still dark</>;
      return e.ticket ? <><b>Open</b><br />With City Corporation</> : <><b>Not raised</b><br />Run a partner sync</>;
    };
    return (
      <>
        <p className="pt-kicker">CITY AUTHORITY · PUBLIC + PRIVATE FUSION</p>
        <h2>Civic Bridge</h2>
        <p className="pt-hint">Private apps already travel every road at night. Government teams fix the roads and answer emergencies. NightWing connects the two in both directions.</p>
        <div className="pt-flow">
          <div className="pt-lane"><h4><Truck size={14} /> Private partners send in</h4><ul><li><b>Delivery fleets:</b> light and pothole readings from riders' phones</li><li><b>Ride-hailing apps:</b> trip details for Ride Watch</li><li><b>Navigation apps:</b> receive the Danger Index</li></ul></div>
          <div className="pt-arrow">verified data in · repair status back</div>
          <div className="pt-lane pt-lane-core"><h4>NightWing</h4><p>Checks readings across many trips, scores danger, diagnoses faults and tracks every case until residents confirm it is fixed.</p></div>
          <div className="pt-arrow">tickets and escalations out · fixes and responses back</div>
          <div className="pt-lane"><h4><Landmark size={14} /> Government services receive</h4><ul><li><b>City Corporation:</b> ranked streetlight and pothole tickets</li><li><b>Electricity Board:</b> area outage reports</li><li><b>Police control room (112 / Kavalan SOS):</b> Ride Watch escalations</li></ul></div>
        </div>
        <button type="button" className="pt-btn pt-btn-primary" onClick={partnerSync}><RefreshCw size={14} /> Run tonight's partner sync</button>
        <p className="pt-mini-title">Joint Safety Ledger</p>
        <p className="pt-fine">One shared record of who found each problem, who owns the fix, and who confirmed it.</p>
        <div className="pt-ledger-wrap">
          <table className="pt-ledger" aria-label="Joint Safety Ledger">
            <thead><tr><th scope="col">Road</th><th scope="col">Found by</th><th scope="col">Government ticket</th><th scope="col">Status</th></tr></thead>
            <tbody>{list.map((e) => (
              <tr key={e.id}><td><b>{e.name}</b><br /><small>{e.area}</small></td><td>{e.foundBy || (e.fault === "bulb" ? "NightWing outage check" : "Citizen trips")}<br /><small>{e.reports} reading{e.reports === 1 ? "" : "s"}</small></td><td>{e.ticket ? <><b>{e.ticket}</b><br /><small>City Corporation</small></> : <small>Not raised yet</small>}</td><td>{status(e)}</td></tr>
            ))}</tbody>
          </table>
        </div>
        <p className="pt-mini-title">Bridge activity</p>
        <Log items={bridgeLog} empty="Run a partner sync to see data flow between partners and departments." />
        <p className="pt-fine">Partner apps and departments are simulated. These integrations are planned, not live.</p>
      </>
    );
  }

  const who = session.role === "citizen"
    ? `${session.name} · Citizen${session.womanVerified ? " · Verified woman" : ""}`
    : `${session.officerId} · Ward officer`;

  return (
    <div className="pt-app">
      <header className="pt-bar">
        <div className="pt-bar-in">
          <a className="brand" href="/" aria-label="NightWing home">
            <span className="brand-symbol" aria-hidden="true">
              <svg viewBox="0 0 40 40" fill="none"><path d="M7 23.5C13.4 21.1 19.8 15.8 23 8c4.8 6.5 7.3 13.9 7.1 21.8-7.3-1.6-14.9-3.7-23.1-6.3Z" fill="currentColor" opacity=".17" /><path d="M8 23.5C15.4 20.9 20.6 16 23.3 8.5M8 23.5c6.1 2.1 12.1 4 21.8 6.1M14.5 20.2c2.6 3.4 5.3 5.6 9.2 7.2M17.8 16.9c2.3 3.4 4.1 5.3 6.9 6.9" stroke="currentColor" strokeWidth="2.25" strokeLinecap="round" strokeLinejoin="round" /><circle cx="30.8" cy="9.3" r="3.2" fill="#F3A26E" /></svg>
            </span>
            <span className="brand-name">NightWing<span className="brand-period">.</span></span>
          </a>
          <span className="pt-app-name">{citizen ? "Citizen app" : "City Authority console"}</span>
          <div className="pt-user"><span className="pt-chip pt-chip-ink">{who}</span><button type="button" className="pt-btn pt-btn-sm" onClick={onSignOut}><LogOut size={14} /> Sign out</button></div>
        </div>
        <nav className="pt-tabs" role="tablist" aria-label="Views">
          {tabs.map((t) => <button key={t.id} type="button" role="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)}>{t.icon}{t.label}</button>)}
        </nav>
      </header>

      <main className="pt-main">
        <section className="pt-mapcard" aria-label="Danger Index map">
          <div className="pt-toolbar">
            <div className="pt-time"><label htmlFor="pt-hour">TIME OF NIGHT</label><input id="pt-hour" type="range" min={20} max={26} step={1} value={hour} onChange={(e) => setHour(Number(e.target.value))} /><output htmlFor="pt-hour">{hourLabel(hour)}</output></div>
            <div className="legend-row pt-legend"><span><i className="legend-dot legend-red" /> Dark + pothole</span><span><i className="legend-dot legend-orange" /> Dark</span><span><i className="legend-dot legend-green" /> Lower risk</span><span><i className="pt-legend-route" /> Safer route</span></div>
          </div>
          <div className="pt-mapwrap">{map}</div>
          <p className="pt-note"><MapPin size={13} /> Simulated pilot neighbourhood, not live data. White rings are confirmed potholes, warm halos are working streetlights, and squares are Safe Spots (+ pharmacy, P police, F petrol).</p>
        </section>
        <aside className="pt-panel">
          {tab === "map" && seePanel()}
          {tab === "route" && routePanel()}
          {tab === "women" && womanVerified && womenPanel()}
          {tab === "repairs" && repairsPanel()}
          {tab === "bridge" && bridgePanel()}
        </aside>
      </main>

      {checkin && (
        <div className="pt-modal" role="dialog" aria-modal="true" aria-labelledby="pt-ci-title">
          <div className="pt-modal-box">
            <p className="pt-kicker">SMART CHECK-IN</p>
            <h3 id="pt-ci-title">Are you okay?</h3>
            <p>Your ride stopped unexpectedly on a dark stretch. If you don't reply, your trusted contacts are alerted.</p>
            <div className="pt-ring">{checkin.count}</div>
            <p className="pt-fine">Prototype timer: 10 seconds. The app would wait 60.</p>
            <button type="button" className="pt-btn pt-btn-primary" autoFocus onClick={() => { clearCheckin(); addCab("Rider confirmed she is safe. No alert sent.", "ok"); }}>I'm safe</button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */
export default function Prototype() {
  const [session, setSession] = useState<Session | null>(null);
  useEffect(() => { document.title = "NightWing — Working prototype"; }, []);
  return session ? <Workspace key={JSON.stringify(session)} session={session} onSignOut={() => setSession(null)} /> : <SignIn onEnter={setSession} />;
}
